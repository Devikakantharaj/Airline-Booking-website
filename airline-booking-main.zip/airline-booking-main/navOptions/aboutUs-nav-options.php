<?php
// Define an array to store the navigation options
$navOptions = array(
    "Home" => "index.php",
    "Book Now" => "booking-form.php",
    // "About Us" => "aboutUs.php",
    "Sign up" => array(
        "Customer" => "signup.php",
        // "Airline" => "#"
    ),
    "Login" => array(
        "Customer" => "login.php",
        "Airline" => "login.php",
        "Admin" => "login.php"
    )
);
?>

