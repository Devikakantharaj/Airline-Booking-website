<!-- Include CSS -->
<link rel="stylesheet" type="text/css" href="css/showMessage.css">

<!-- Include JavaScript -->
<script src="js/showMessage.js"></script>