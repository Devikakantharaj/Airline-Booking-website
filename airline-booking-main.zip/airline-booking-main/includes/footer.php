  <footer>
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="aboutUs.php">About Us</a></li>
      <li><a href="aboutUs.php#targeting-contact">Contact</a></li>
      <li><a href="booking-form.php">Services</a></li>
    </ul>
    <p>&copy 2023 EASYFLY, all right reserved</p>
  </footer>
</body>

</html>